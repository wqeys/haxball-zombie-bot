# HaxBall Zombie Survival Engine

Fully automatic **Zombie Survival / Wave Survival** game mode built on **Node-HaxBall**.

Not a classic admin/stat bot — the game loop runs by itself with fake-player zombies, wave state machine, infection, persistent stats, ranks, records, AFK/spam/troll protection and random events.

## Requirements

- Node.js ≥ 18
- A HaxBall recaptcha token: https://www.haxball.com/headlesstoken
- Your own stadium/map (`.hbs`) — the engine does **not** modify geometry

## Install

```bash
npm install
```

## Run

```bash
TOKEN=your_token_here npm start
```

## Map setup

Place spawn coordinates in `src/config.js`:

```js
spawn: {
  human:  [ { x: 200, y: 0 }, { x: 220, y: 40 } ],
  zombie: [ { x: -200, y: 0 }, { x: -180, y: -50 } ],
  boss:   [ { x: -250, y: 0 } ],
  safeZones: [ { x: 0, y: 0, radius: 80 } ]
}
```

Load your stadium after room open (uncomment in `src/main.js`):

```js
const stadiumData = fs.readFileSync("./maps/zombie.hbs", "utf8");
room.setCurrentStadium(Utils.parseStadium(stadiumData), 0);
```

## Core rules (implemented as state machine)

```
WAITING → RUN START → WAVE 1 → … → WAVE N
                ↓
        all zombies dead & ≥1 human alive → next wave
                ↓
        0 humans alive → RUN LOST → reset → WAVE 1
```

- Last human standing keeps the run alive.
- Dead/infected players respawn at the start of the next wave.
- Full wipe → everyone infected message + run restart.

## Teams

| Team  | Role   |
|-------|--------|
| BLUE  | Human  |
| RED   | Zombie (fake players + infected humans) |

## Zombie types

`NORMAL`, `FAST`, `TANK`, `RUNNER`, `BOSS` — each with own radius, invMass, speed, attack range/cooldown (config).

Boss every `bossWaveInterval` waves (default 5).

## Commands

| Command    | Description              |
|------------|--------------------------|
| `!stats`   | Full personal stats      |
| `!profile` | Short profile            |
| `!rank`    | Current rank + score     |
| `!top`     | Leaderboard              |
| `!records` | Global records           |
| `!wave`    | Current wave info        |
| `!run`     | Active run summary       |
| `!help`    | List commands            |

## Config highlights (`src/config.js`)

- Wave growth, max zombies, player-count scaling
- Infection on/off + distances
- All zombie type physics
- Anti-camp / AFK / spam / troll thresholds
- Rank thresholds & score weights
- Random event list & chance
- Message templates

## Architecture

```
src/
  main.js
  config.js
  game/
    gameManager.js      # state machine
    waveManager.js
    runManager.js
    spawnManager.js
  zombies/
    zombieManager.js
    zombie.js
    zombieTypes.js
    zombieMovement.js   # script input via fakeSendPlayerInput
    zombieCombat.js
  players/
    playerManager.js
    infection.js
    respawn.js
  systems/
    stats.js  rank.js  leaderboard.js
    afk.js  antiSpam.js  antiTroll.js  antiExploit.js
  events/
    eventManager.js  randomEvents.js  bossEvents.js
  database/
    database.js         # JSON file store
  commands/
    commands.js
  utils/
    logger.js  timers.js
```

## Node-HaxBall APIs used (real only)

- `Room.create`
- `fakePlayerJoin` / `fakePlayerLeave`
- `fakeSendPlayerInput` + `Utils.keyState`
- `setPlayerTeam` / `setPlayerDiscProperties` / `setPlayerAvatar`
- `sendAnnouncement` / `kickPlayer`
- `onPlayerJoin` / `Leave` / `Chat` / `GameTick` / `BallKick` / `OperationReceived`
- Room state disc access

No AI / ML / reinforcement learning. Zombies are deterministic script bots.

## Notes

- Stats persist in `data/stats.json`.
- Admin is not required after the room is up.
- Tune `movement.updateIntervalMs` if CPU is high with many zombies.
- Fill `config.spawn.*` to match your map for best results.
