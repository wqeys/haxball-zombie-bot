const config = require("../config");
const log = require("../utils/logger");

class AntiTroll {
  constructor(room) {
    this.room = room;
    this.scores = new Map(); // id -> score
    this.lastDecay = Date.now();
  }

  add(playerId, reason, points) {
    if (!config.troll.enabled) return;
    const cur = this.scores.get(playerId) || 0;
    const next = cur + points;
    this.scores.set(playerId, next);
    log.antitroll(`Player ${playerId} +${points} (${reason}) -> ${next}`);

    if (next >= config.troll.kickThreshold) {
      this.room.kickPlayer?.(playerId, "Troll behaviour", false);
      this.scores.delete(playerId);
    } else if (next >= config.troll.restrictThreshold) {
      this.room.sendAnnouncement?.(
        "⚠ Restrictive behaviour detected. Stop or face kick.",
        playerId, 0xff6600, "bold", 2
      );
    } else if (next >= config.troll.warnThreshold) {
      this.room.sendAnnouncement?.(
        "⚠ Warning: disruptive behaviour.",
        playerId, 0xffaa00, "bold", 1
      );
    }
  }

  decay() {
    const now = Date.now();
    if (now - this.lastDecay < 60000) return;
    this.lastDecay = now;
    for (const [id, sc] of this.scores) {
      const n = Math.max(0, sc - config.troll.decayPerMinute);
      if (n === 0) this.scores.delete(id);
      else this.scores.set(id, n);
    }
  }

  onLeave(id) {
    this.scores.delete(id);
  }
}

module.exports = AntiTroll;
