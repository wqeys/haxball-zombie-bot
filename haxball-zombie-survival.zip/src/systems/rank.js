const config = require("../config");

function computeScore(stats) {
  const w = config.rankWeights;
  let score = 0;
  score += (stats.kills || 0) * w.kills;
  score += (stats.zombieKills || 0) * w.zombieKills;
  score += (stats.bossKills || 0) * w.bossKills;
  score += (stats.wavesSurvived || 0) * w.wavesSurvived;
  score += (stats.highestWave || 0) * w.highestWave;
  score += ((stats.survivalTime || 0) / 60000) * w.survivalMinutes;
  score += (stats.infections || 0) * w.infections;
  score += (stats.deaths || 0) * w.deaths;
  score += (stats.wins || 0) * w.wins;
  return Math.max(0, Math.floor(score));
}

function getRank(score) {
  let rank = config.ranks[0];
  for (const r of config.ranks) {
    if (score >= r.minScore) rank = r;
  }
  return rank.name;
}

function updatePlayerRank(stats) {
  stats.score = computeScore(stats);
  stats.rank = getRank(stats.score);
  return stats;
}

module.exports = { computeScore, getRank, updatePlayerRank };
