const config = require("../config");
const log = require("../utils/logger");

class AfkSystem {
  constructor(room, gameManager) {
    this.room = room;
    this.gm = gameManager;
    this.lastActivity = new Map(); // id -> { time, x, y, input }
    this.warned = new Set();
    this.timer = null;
  }

  start() {
    if (!config.afk.enabled) return;
    this.timer = setInterval(() => this._tick(), config.afk.checkIntervalMs);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
  }

  onActivity(playerId, kind = "input") {
    const now = Date.now();
    const prev = this.lastActivity.get(playerId) || {};
    this.lastActivity.set(playerId, {
      time: now,
      kind,
      x: prev.x,
      y: prev.y
    });
    this.warned.delete(playerId);
  }

  onPosition(playerId, x, y) {
    const prev = this.lastActivity.get(playerId);
    if (!prev) {
      this.lastActivity.set(playerId, { time: Date.now(), x, y });
      return;
    }
    const dist = Math.hypot((x || 0) - (prev.x || 0), (y || 0) - (prev.y || 0));
    if (dist > 15) {
      this.lastActivity.set(playerId, { time: Date.now(), x, y, kind: "move" });
      this.warned.delete(playerId);
    }
  }

  onChat(playerId) {
    this.onActivity(playerId, "chat");
  }

  onLeave(playerId) {
    this.lastActivity.delete(playerId);
    this.warned.delete(playerId);
  }

  _tick() {
    const now = Date.now();
    const players = this.room.players || [];
    for (const p of players) {
      if (p.id === 0) continue; // host
      if (this.gm.isFakeZombie(p.id)) continue;

      const act = this.lastActivity.get(p.id);
      if (!act) {
        this.lastActivity.set(p.id, { time: now });
        continue;
      }

      const idle = now - act.time;
      const team = p.team?.id ?? p.team;

      if (idle >= config.afk.spectateMs && team !== 0) {
        log.afk(`${p.name} AFK -> spectator`);
        this.room.setPlayerTeam?.(p.id, 0);
        this.room.sendAnnouncement?.(config.messages.afkSpec(), p.id, 0xffaa00, "bold", 1);
        this.warned.delete(p.id);
        if (config.afk.kickMs > 0 && idle >= config.afk.kickMs) {
          this.room.kickPlayer?.(p.id, "AFK", false);
        }
      } else if (idle >= config.afk.warnMs && !this.warned.has(p.id)) {
        this.warned.add(p.id);
        this.room.sendAnnouncement?.(config.messages.afkWarn(), p.id, 0xffaa00, "bold", 1);
        log.afk(`${p.name} AFK warning`);
      }
    }
  }
}

module.exports = AfkSystem;
