const db = require("../database/database");
const { updatePlayerRank } = require("./rank");
const log = require("../utils/logger");

class StatsSystem {
  constructor() {
    this.sessionStart = new Map(); // auth -> timestamp
  }

  onJoin(player) {
    if (!player.auth) return;
    const s = db.getPlayer(player.auth);
    s.name = player.name;
    this.sessionStart.set(player.auth, Date.now());
    updatePlayerRank(s);
    db._dirty = true;
  }

  onLeave(player) {
    if (!player.auth) return;
    const start = this.sessionStart.get(player.auth);
    if (start) {
      const elapsed = Date.now() - start;
      db.addStat(player.auth, "totalPlayTime", elapsed);
      this.sessionStart.delete(player.auth);
    }
    const s = db.getPlayer(player.auth);
    updatePlayerRank(s);
  }

  addKill(auth, isZombieKill = false) {
    db.addStat(auth, "kills");
    if (isZombieKill) db.addStat(auth, "zombieKills");
    updatePlayerRank(db.getPlayer(auth));
  }

  addDeath(auth) {
    db.addStat(auth, "deaths");
    updatePlayerRank(db.getPlayer(auth));
  }

  addInfection(auth) {
    db.addStat(auth, "infections");
    updatePlayerRank(db.getPlayer(auth));
  }

  addBossKill(auth) {
    db.addStat(auth, "bossKills");
    db.addStat(auth, "zombieKills");
    updatePlayerRank(db.getPlayer(auth));
  }

  waveSurvived(auth, waveNum) {
    db.addStat(auth, "wavesSurvived");
    const s = db.getPlayer(auth);
    if (waveNum > (s.highestWave || 0)) {
      s.highestWave = waveNum;
      db._dirty = true;
    }
    updatePlayerRank(s);
  }

  runEnded(auth, waveReached, survived, durationMs) {
    db.addStat(auth, "runs");
    if (survived) db.addStat(auth, "wins");
    else db.addStat(auth, "losses");
    db.addStat(auth, "survivalTime", durationMs);
    const s = db.getPlayer(auth);
    if (waveReached > (s.bestRun || 0)) {
      s.bestRun = waveReached;
      db._dirty = true;
    }
    updatePlayerRank(s);

    // Global records
    db.tryRecord("highestWave", waveReached, s.name);
    db.tryRecord("longestSurvival", durationMs, s.name);
    db.tryRecord("mostZombieKills", s.zombieKills, s.name);
    db.tryRecord("bestRun", waveReached, s.name);
    db.tryRecord("mostBossKills", s.bossKills, s.name);
  }

  getProfile(auth) {
    const s = db.getPlayer(auth);
    updatePlayerRank(s);
    return s;
  }

  formatPlayTime(ms) {
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    return `${h}h ${m}m`;
  }
}

module.exports = new StatsSystem();
