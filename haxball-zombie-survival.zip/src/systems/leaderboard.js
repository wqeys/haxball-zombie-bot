const db = require("../database/database");
const { updatePlayerRank } = require("./rank");
const statsSys = require("./stats");

function formatTop(n = 10) {
  const top = db.getTop(n);
  if (!top.length) return "No stats yet.";
  const lines = top.map((p, i) => {
    updatePlayerRank(p);
    return `${i + 1}. ${p.name || "?"} [${p.rank}] — Score ${p.score} | Kills ${p.zombieKills} | Wave ${p.highestWave}`;
  });
  return "🏆 TOP PLAYERS\n" + lines.join("\n");
}

function formatRecords() {
  const r = db.getRecords();
  return [
    "🏆 GLOBAL RECORDS",
    `Highest Wave: ${r.highestWave.value} (${r.highestWave.player || "-"})`,
    `Longest Survival: ${statsSys.formatPlayTime(r.longestSurvival.value)} (${r.longestSurvival.player || "-"})`,
    `Most Zombie Kills: ${r.mostZombieKills.value} (${r.mostZombieKills.player || "-"})`,
    `Best Run: Wave ${r.bestRun.value} (${r.bestRun.player || "-"})`,
    `Most Boss Kills: ${r.mostBossKills.value} (${r.mostBossKills.player || "-"})`
  ].join("\n");
}

function formatStats(playerStats) {
  updatePlayerRank(playerStats);
  return [
    `📊 ${playerStats.name || "Player"}`,
    `Rank: ${playerStats.rank}`,
    `Score: ${playerStats.score}`,
    `Highest Wave: ${playerStats.highestWave}`,
    `Best Run: Wave ${playerStats.bestRun}`,
    `Zombie Kills: ${playerStats.zombieKills}`,
    `Boss Kills: ${playerStats.bossKills}`,
    `Waves Survived: ${playerStats.wavesSurvived}`,
    `Survival Time: ${statsSys.formatPlayTime(playerStats.survivalTime)}`,
    `Runs: ${playerStats.runs} (W:${playerStats.wins} L:${playerStats.losses})`,
    `Deaths: ${playerStats.deaths} | Infections caused: ${playerStats.infections}`
  ].join("\n");
}

function formatProfile(playerStats) {
  updatePlayerRank(playerStats);
  return [
    `${playerStats.name}`,
    `Rank: ${playerStats.rank}`,
    `Highest Wave: ${playerStats.highestWave}`,
    `Best Run: Wave ${playerStats.bestRun}`,
    `Zombie Kills: ${playerStats.zombieKills}`,
    `Survival Time: ${statsSys.formatPlayTime(playerStats.survivalTime)}`,
    `Boss Kills: ${playerStats.bossKills}`
  ].join("\n");
}

module.exports = { formatTop, formatRecords, formatStats, formatProfile };
