const config = require("../config");
const log = require("../utils/logger");

class AntiSpam {
  constructor(room) {
    this.room = room;
    this.history = new Map(); // id -> [{ts, msg}]
    this.mutes = new Map();   // id -> until
    this.muteCount = new Map();
  }

  onChat(player, message) {
    const id = player.id;
    const now = Date.now();

    // Mute check
    const until = this.mutes.get(id);
    if (until && now < until) {
      return false; // block
    }

    if (message.length > config.spam.maxMessageLength) {
      this.room.sendAnnouncement?.("Message too long.", id, 0xff0000, "bold", 1);
      return false;
    }

    let hist = this.history.get(id) || [];
    hist = hist.filter(h => now - h.ts < config.spam.windowMs);
    hist.push({ ts: now, msg: message });
    this.history.set(id, hist);

    // Same message spam
    const same = hist.filter(h => h.msg === message).length;
    if (same >= 4) {
      this._punish(player, "Repeated message spam");
      return false;
    }

    if (hist.length >= config.spam.maxMessagesPerWindow) {
      this._punish(player, "Flood");
      return false;
    }

    return true;
  }

  _punish(player, reason) {
    const id = player.id;
    const count = (this.muteCount.get(id) || 0) + 1;
    this.muteCount.set(id, count);
    this.mutes.set(id, Date.now() + config.spam.muteMs);
    log.antispam(`${player.name} muted (${reason}) count=${count}`);
    this.room.sendAnnouncement?.(
      `Muted ${Math.round(config.spam.muteMs / 1000)}s — ${reason}`,
      id, 0xff0000, "bold", 2
    );
    if (count >= config.spam.kickAfterMutes) {
      this.room.kickPlayer?.(id, "Chat spam", false);
    }
  }

  onLeave(id) {
    this.history.delete(id);
    this.mutes.delete(id);
  }
}

module.exports = AntiSpam;
