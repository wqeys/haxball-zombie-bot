/**
 * Central configuration for HaxBall Zombie Survival
 * Secrets (token, admin auth, webhook) come from .env — never hard-code them.
 */

module.exports = {
  // ─── Room ───────────────────────────────────────────────────────────────
  room: {
    name: "☣ Zombie Survival ☣",
    password: null,
    maxPlayers: 20,
    public: true,
    noPlayer: true,
    geo: { code: "TR", lat: 41.0, lon: 29.0 }
  },

  // Prefer process.env.ADMIN_AUTH (comma-separated). Optional local fallback:
  adminAuths: [],

  debug: process.env.DEBUG === "true",

  // ─── Teams ──────────────────────────────────────────────────────────────
  teams: {
    HUMAN: 2,                // BLUE
    ZOMBIE: 1,               // RED
    SPECTATOR: 0
  },

  // ─── Wave / Run ─────────────────────────────────────────────────────────
  wave: {
    baseZombieCount: 2,
    zombiesPerWave: 1.4,
    maxZombieCount: 18,
    waveMultiplier: 1.15,
    intermissionMs: 5000,    // also drives avatar countdown seconds
    minHumansToContinue: 1,
    bossWaveInterval: 5
  },

  // Wave intermission: avatar shows remaining seconds (97, 96, ... 1)
  // intermissionMs above controls total length (e.g. 97000 → 97s countdown)
  countdown: {
    enabled: true,
    forSpectators: true,
    // max 2 chars on HaxBall avatar; values >99 display as "99"
    waveStartAvatar: "⚔"
  },

  playerScale: [
    { maxPlayers: 2,  multiplier: 0.7 },
    { maxPlayers: 4,  multiplier: 0.9 },
    { maxPlayers: 6,  multiplier: 1.0 },
    { maxPlayers: 8,  multiplier: 1.15 },
    { maxPlayers: 99, multiplier: 1.3 }
  ],

  // Reinforcements during a wave (seconds after wave start → extra zombies)
  reinforcement: {
    enabled: true,
    schedule: [
      { afterSec: 20, count: 2, types: ["RUNNER", "NORMAL"] },
      { afterSec: 45, count: 3, types: ["NORMAL", "SWARMER"] },
      { afterSec: 90, count: 1, types: ["HUNTER"] }
    ]
  },

  // ─── Infection ──────────────────────────────────────────────────────────
  infection: {
    enabled: true,
    infectOnTouch: true,
    touchDistance: 28,
    infectCooldownMs: 1200,
    // Real player → SPECTATOR; fake zombie spawned with ownerPlayerId
    moveToSpectator: true,
    zombieAvatar: "🧟"
  },

  // ─── Zombie Types ───────────────────────────────────────────────────────
  zombieTypes: {
    NORMAL: {
      name: "Zombie",
      avatar: "🧟",
      speed: 0.85,
      radius: 15,
      invMass: 0.6,
      bCoef: 0.5,
      kickPower: 0.4,
      attackRange: 32,
      attackCooldownMs: 900,
      color: 0x2d5a27,
      weight: 40,
      behavior: "nearest"
    },
    RUNNER: {
      name: "Runner",
      avatar: "🏃",
      speed: 1.55,
      radius: 12,
      invMass: 1.0,
      bCoef: 0.3,
      kickPower: 0.25,
      attackRange: 28,
      attackCooldownMs: 600,
      color: 0xff4500,
      weight: 18,
      behavior: "isolate"      // prefer lone survivors
    },
    TANK: {
      name: "Tank",
      avatar: "🛡",
      speed: 0.5,
      radius: 22,
      invMass: 0.22,
      bCoef: 1.3,
      kickPower: 1.2,
      attackRange: 42,
      attackCooldownMs: 1400,
      color: 0x4a3728,
      weight: 10,
      behavior: "nearest"
    },
    HUNTER: {
      name: "Hunter",
      avatar: "🎯",
      speed: 1.15,
      radius: 14,
      invMass: 0.7,
      bCoef: 0.45,
      kickPower: 0.5,
      attackRange: 34,
      attackCooldownMs: 800,
      color: 0x9400d3,
      weight: 12,
      behavior: "isolate"
    },
    SWARMER: {
      name: "Swarmer",
      avatar: "🐝",
      speed: 1.0,
      radius: 13,
      invMass: 0.85,
      bCoef: 0.35,
      kickPower: 0.3,
      attackRange: 30,
      attackCooldownMs: 750,
      color: 0xffd700,
      weight: 15,
      behavior: "swarm"         // pack near other zombies
    },
    BOSS: {
      name: "ZOMBIE BOSS",
      avatar: "💀",
      speed: 0.95,
      radius: 28,
      invMass: 0.15,
      bCoef: 1.5,
      kickPower: 1.8,
      attackRange: 48,
      attackCooldownMs: 1100,
      color: 0x8b0000,
      weight: 0,
      behavior: "boss"
    }
  },

  // Composition by wave band (type keys + relative weight)
  difficultyBands: [
    { maxWave: 3,  types: { NORMAL: 80, RUNNER: 20 } },
    { maxWave: 6,  types: { NORMAL: 50, RUNNER: 35, SWARMER: 15 } },
    { maxWave: 9,  types: { NORMAL: 30, RUNNER: 25, TANK: 20, HUNTER: 15, SWARMER: 10 } },
    { maxWave: 14, types: { NORMAL: 20, RUNNER: 25, TANK: 20, HUNTER: 20, SWARMER: 15 } },
    { maxWave: 99, types: { NORMAL: 15, RUNNER: 25, TANK: 20, HUNTER: 25, SWARMER: 15 } }
  ],

  movement: {
    updateIntervalMs: 50,
    targetRecalcEvery: 4,
    maxChaseDistance: 1200,
    stuckThresholdMs: 4000,
    inputReleaseKickFrames: 2
  },

  // Map: Zombiee.hbs — red left / blue right
  spawn: {
    human: [
      { x: 150, y: 0 },
      { x: 160, y: 0 },
      { x: 150, y: 40 },
      { x: 150, y: -40 }
    ],
    zombie: [
      { x: -150, y: 0 },
      { x: -160, y: 0 },
      { x: -150, y: 50 },
      { x: -150, y: -50 },
      { x: -200, y: 0 },
      { x: -180, y: 80 },
      { x: -180, y: -80 }
    ],
    boss: [
      { x: -220, y: 0 },
      { x: -200, y: 60 }
    ],
    safeZones: []
  },

  stadiumPath: "./maps/Zombiee.hbs",

  antiCamp: {
    enabled: true,
    checkIntervalMs: 5000,
    warnAfterMs: 30000,
    reinforceAfterMs: 60000,
    punishAfterMs: 90000,
    movementThreshold: 40
  },

  afk: {
    enabled: true,
    warnMs: 45000,
    spectateMs: 90000,
    kickMs: 0,
    checkIntervalMs: 5000
  },

  spam: {
    maxMessagesPerWindow: 6,
    windowMs: 5000,
    muteMs: 30000,
    kickAfterMutes: 3,
    maxMessageLength: 140
  },

  troll: {
    enabled: true,
    warnThreshold: 30,
    restrictThreshold: 60,
    kickThreshold: 80,
    decayPerMinute: 2,
    points: {
      teamDamage: 8,
      spawnBlock: 5,
      kickSpam: 10,
      afkDuringWave: 4,
      exploitInput: 15
    }
  },

  events: {
    enabled: true,
    chancePerWave: 0.22,
    minWave: 3,
    list: [
      "ZombieRush",
      "DoubleZombies",
      "FastZombies",
      "LowGravity",
      "SuperKnockback",
      "NoSafeZone",
      "OneMinuteHorde"
    ]
  },

  ranks: [
    { name: "ROOKIE",       minScore: 0 },
    { name: "SURVIVOR",     minScore: 150 },
    { name: "HUNTER",       minScore: 400 },
    { name: "VETERAN",      minScore: 900 },
    { name: "ELITE",        minScore: 1800 },
    { name: "APOCALYPSE",   minScore: 3500 },
    { name: "LEGEND",       minScore: 7000 }
  ],

  rankWeights: {
    kills: 2,
    zombieKills: 3,
    bossKills: 25,
    wavesSurvived: 8,
    highestWave: 15,
    survivalMinutes: 1.5,
    infections: -1,
    deaths: -0.5,
    wins: 40,
    lastStandSurvived: 30
  },

  database: {
    path: "./data/stats.json",
    saveIntervalMs: 30000
  },

  log: {
    level: "info",
    prefixes: {
      ROOM: "[ROOM]",
      WAVE: "[WAVE]",
      ZOMBIE: "[ZOMBIE]",
      PLAYER: "[PLAYER]",
      INFECTION: "[INFECTION]",
      BOSS: "[BOSS]",
      AFK: "[AFK]",
      ANTISPAM: "[ANTISPAM]",
      ANTITROLL: "[ANTITROLL]",
      STATS: "[STATS]",
      EVENT: "[EVENT]",
      RUN: "[RUN]",
      ADMIN: "[ADMIN]"
    }
  },

  messages: {
    waveStart: (n, z) => `☣ WAVE ${n}  —  🧟 ${z} ZOMBIES`,
    waveClear: (n, s) => `🔥 WAVE ${n} CLEARED  —  👤 ${s} SURVIVORS`,
    bossWave: () => `☠ BOSS WAVE  —  THE ZOMBIE BOSS HAS SPAWNED`,
    runLost: (w) => `☠ EVERYONE WAS INFECTED\nRUN LOST — WAVE 1 RESTARTING (was Wave ${w})`,
    infected: (name) => `💀 ${name} HAS BEEN INFECTED`,
    playerJoinMid: (w) => `Wave ${w} active. Waiting for next spawn...`,
    intermission: (ms) => `⏳ Next wave in ${Math.round(ms / 1000)}s`,
    campWarn: () => `⚠ MOVE!`,
    campDetected: () => `⚠ CAMPING DETECTED`,
    campReinforce: () => `Zombie reinforcement incoming.`,
    afkWarn: () => `⚠ AFK WARNING`,
    afkSpec: () => `Moved to spectators (AFK)`,
    lastSurvivor: (name) => `⚠ LAST SURVIVOR — ${name}`
  }
};
