/**
 * HaxBall Zombie Survival — entry point
 *
 * PowerShell:
 *   $env:HAXBALL_TOKEN="..."; $env:ADMIN_AUTH="..."; npm start
 *
 * Secrets only via .env / environment — never logged.
 */

require("dotenv").config();

const fs = require("fs");
const path = require("path");
const config = require("./config");
const log = require("./utils/logger");
const db = require("./database/database");
const GameManager = require("./game/gameManager");
const { handleCommand } = require("./commands/commands");
const { isAuthorizedAdmin } = require("./auth/admin");

const API = require("node-haxball")();
const { Room, Utils } = API;

const TOKEN =
  process.env.HAXBALL_TOKEN || process.env.TOKEN || process.env.HB_TOKEN || "";

if (!TOKEN) {
  console.error(
    "Missing HAXBALL_TOKEN. Set it in .env or environment (see .env.example)."
  );
  process.exit(1);
}

db.load();
db.startAutoSave();

let gameManager = null;

function bindRoomEvents(room) {
  room.onPlayerJoin = (player) => {
    if (gameManager) gameManager.onPlayerJoin(player);

    if (isAuthorizedAdmin(player)) {
      try {
        room.setPlayerAdmin(player.id, true);
        log.room(`Admin granted: ${player.name}`);
      } catch (e) {
        log.warn("setPlayerAdmin failed");
      }
    }
  };

  room.onPlayerLeave = (player) => {
    if (gameManager) gameManager.onPlayerLeave(player);
  };

  room.onPlayerChat = (player, message) => {
    if (!gameManager) return true;
    const allowed = gameManager.onPlayerChat(player, message);
    if (allowed === false) return false;
    if (message.startsWith("!")) {
      handleCommand(room, player, message, gameManager);
      return false;
    }
    return true;
  };

  room.onPlayerBallKick = (playerId) => {
    if (gameManager) gameManager.onPlayerBallKick(playerId);
  };

  room.onGameTick = () => {
    if (gameManager) gameManager.onGameTick();
  };

  room.onGameStart = () => {
    log.room("Game started");
    if (gameManager) gameManager.gameStarted = true;
  };

  room.onGameStop = () => {
    log.room("Game stopped");
    if (gameManager) gameManager.gameStarted = false;
  };

  room.onOperationReceived = () => true;
}

function loadStadium(room) {
  const rel = config.stadiumPath || "./maps/Zombiee.hbs";
  const full = path.resolve(process.cwd(), rel);
  if (!fs.existsSync(full)) {
    log.warn("Stadium file not found:", rel);
    return;
  }
  try {
    const raw = fs.readFileSync(full, "utf8");
    const stadium = Utils.parseStadium
      ? Utils.parseStadium(raw)
      : JSON.parse(raw);
    room.setCurrentStadium?.(stadium, 0);
    log.room("Stadium loaded:", path.basename(full));
  } catch (e) {
    log.error("Stadium load failed:", e.message);
  }
}

Room.create(
  {
    name: config.room.name,
    password: config.room.password,
    maxPlayerCount: config.room.maxPlayers,
    showInRoomList: config.room.public,
    token: TOKEN,
    noPlayer: config.room.noPlayer,
    geo: config.room.geo
  },
  {
    storage: {
      player_name: "ZombieHost",
      avatar: "☣"
    },
    onOpen: (room) => {
      log.room("Room opened");
      gameManager = new GameManager(room, Utils);
      gameManager.startSystems();
      bindRoomEvents(room);
      loadStadium(room);

      try {
        room.setScoreLimit?.(0);
        room.setTimeLimit?.(0);
        room.setTeamsLock?.(true);
      } catch (_) {}

      room.sendAnnouncement?.(
        "☣ ZOMBIE SURVIVAL  —  Survive the waves!",
        null,
        0x00ff88,
        "bold",
        2
      );
      room.sendAnnouncement?.(
        "Commands: !help !stats !rank !top !records",
        null,
        0xaaaaaa,
        "normal",
        1
      );
    },
    onClose: () => {
      log.room("Room closed");
      if (gameManager) gameManager.stopSystems();
      db.stopAutoSave();
    },
    onRoomLink: (link) => {
      log.room("LINK:", link);
      console.log("\n>>> ROOM LINK:", link, "\n");
    }
  }
);

process.on("SIGINT", () => {
  log.room("Shutting down...");
  if (gameManager) gameManager.stopSystems();
  db.stopAutoSave();
  process.exit(0);
});

process.on("SIGTERM", () => {
  if (gameManager) gameManager.stopSystems();
  db.stopAutoSave();
  process.exit(0);
});

log.room("Starting Zombie Survival engine...");
