/**
 * Lightweight interval / timeout manager that can be cleared in bulk
 * (used on run reset / room close).
 */

class TimerManager {
  constructor() {
    this._intervals = new Set();
    this._timeouts = new Set();
  }

  setInterval(fn, ms) {
    const id = setInterval(fn, ms);
    this._intervals.add(id);
    return id;
  }

  setTimeout(fn, ms) {
    const id = setTimeout(() => {
      this._timeouts.delete(id);
      fn();
    }, ms);
    this._timeouts.add(id);
    return id;
  }

  clear(id) {
    if (this._intervals.has(id)) {
      clearInterval(id);
      this._intervals.delete(id);
    }
    if (this._timeouts.has(id)) {
      clearTimeout(id);
      this._timeouts.delete(id);
    }
  }

  clearAll() {
    for (const id of this._intervals) clearInterval(id);
    for (const id of this._timeouts) clearTimeout(id);
    this._intervals.clear();
    this._timeouts.clear();
  }
}

module.exports = TimerManager;
