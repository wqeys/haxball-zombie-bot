const config = require("../config");

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const current = LEVELS[config.log.level] ?? 1;

function ts() {
  return new Date().toISOString().slice(11, 19);
}

function log(prefixKey, level, ...args) {
  if ((LEVELS[level] ?? 1) < current) return;
  const prefix = config.log.prefixes[prefixKey] || `[${prefixKey}]`;
  const tag = level === "error" ? "ERROR" : level === "warn" ? "WARN" : "";
  console.log(`${ts()} ${prefix}${tag ? " " + tag : ""}`, ...args);
}

module.exports = {
  room: (...a) => log("ROOM", "info", ...a),
  wave: (...a) => log("WAVE", "info", ...a),
  zombie: (...a) => log("ZOMBIE", "info", ...a),
  player: (...a) => log("PLAYER", "info", ...a),
  infection: (...a) => log("INFECTION", "info", ...a),
  boss: (...a) => log("BOSS", "info", ...a),
  afk: (...a) => log("AFK", "info", ...a),
  antispam: (...a) => log("ANTISPAM", "info", ...a),
  antitroll: (...a) => log("ANTITROLL", "info", ...a),
  stats: (...a) => log("STATS", "info", ...a),
  event: (...a) => log("EVENT", "info", ...a),
  run: (...a) => log("RUN", "info", ...a),
  debug: (...a) => log("ROOM", "debug", ...a),
  warn: (...a) => log("ROOM", "warn", ...a),
  error: (...a) => log("ROOM", "error", ...a)
};
