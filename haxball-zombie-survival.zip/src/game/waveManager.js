const config = require("../config");
const log = require("../utils/logger");

class WaveManager {
  constructor() {
    this.wave = 0;
    this.state = "WAITING"; // WAITING | INTERMISSION | ACTIVE | CLEARED
    this.zombieTarget = 0;
  }

  reset() {
    this.wave = 0;
    this.state = "WAITING";
    this.zombieTarget = 0;
  }

  /**
   * Calculate zombie count for next wave based on human count.
   */
  calcZombieCount(humanCount) {
    let base = config.wave.baseZombieCount;
    base += Math.floor((this.wave) * config.wave.zombiesPerWave);
    base = Math.floor(base * Math.pow(config.wave.waveMultiplier, Math.max(0, this.wave - 1)));

    // Player scaling
    let mult = 1;
    for (const s of config.playerScale) {
      if (humanCount <= s.maxPlayers) {
        mult = s.multiplier;
        break;
      }
    }
    base = Math.round(base * mult);
    base = Math.min(base, config.wave.maxZombieCount);
    base = Math.max(1, base);
    return base;
  }

  isBossWave() {
    return this.wave > 0 && this.wave % config.wave.bossWaveInterval === 0;
  }

  startNext(humanCount) {
    this.wave++;
    this.zombieTarget = this.calcZombieCount(humanCount);
    this.state = "ACTIVE";
    log.wave(`Wave ${this.wave} started — ${this.zombieTarget} zombies`);
    return { wave: this.wave, zombies: this.zombieTarget, boss: this.isBossWave() };
  }

  markCleared() {
    this.state = "CLEARED";
  }

  markIntermission() {
    this.state = "INTERMISSION";
  }
}

module.exports = WaveManager;
