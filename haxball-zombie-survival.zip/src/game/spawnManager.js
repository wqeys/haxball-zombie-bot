const config = require("../config");

/**
 * Thin helper around configured spawn points.
 */
function randomFrom(list, fallback) {
  if (list && list.length) {
    return list[Math.floor(Math.random() * list.length)];
  }
  return fallback;
}

module.exports = {
  humanSpawn() {
    return randomFrom(config.spawn.human, { x: 200, y: 0 });
  },
  zombieSpawn() {
    return randomFrom(config.spawn.zombie, { x: -200, y: 0 });
  },
  bossSpawn() {
    return randomFrom(config.spawn.boss, { x: -250, y: 0 });
  }
};
