const db = require("../database/database");
const log = require("../utils/logger");
const statsSys = require("../systems/stats");

class RunManager {
  constructor() {
    this.runId = null;
    this.startTime = null;
    this.startPlayers = [];
    this.maxPlayers = 0;
    this.waveReached = 0;
    this.zombieKills = 0;
    this.infections = 0;
    this.active = false;
  }

  start(playerNames) {
    this.runId = db.nextRunId();
    this.startTime = Date.now();
    this.startPlayers = [...playerNames];
    this.maxPlayers = playerNames.length;
    this.waveReached = 0;
    this.zombieKills = 0;
    this.infections = 0;
    this.active = true;
    log.run(`RUN #${this.runId} started with ${playerNames.length} players`);
  }

  updateMaxPlayers(n) {
    if (n > this.maxPlayers) this.maxPlayers = n;
  }

  setWave(w) {
    this.waveReached = w;
  }

  addZombieKill() {
    this.zombieKills++;
  }

  addInfection() {
    this.infections++;
  }

  end(survived, humanAuths) {
    if (!this.active) return;
    this.active = false;
    const duration = Date.now() - this.startTime;
    const summary = [
      `RUN #${this.runId}`,
      `Wave: ${this.waveReached}`,
      `Survivors: ${humanAuths.length}`,
      `Zombie Kills: ${this.zombieKills}`,
      `Duration: ${this._fmt(duration)}`
    ].join("\n");

    log.run(`Run #${this.runId} ended — Wave ${this.waveReached}`);

    for (const auth of humanAuths) {
      statsSys.runEnded(auth, this.waveReached, survived, duration);
    }
    // Also record for players who participated but died
    return summary;
  }

  _fmt(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, "0")}`;
  }

  getSummaryLine() {
    if (!this.active) return null;
    return `RUN #${this.runId} | Wave ${this.waveReached}`;
  }
}

module.exports = RunManager;
