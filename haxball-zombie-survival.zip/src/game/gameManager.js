const config = require("../config");
const log = require("../utils/logger");
const WaveManager = require("./waveManager");
const RunManager = require("./runManager");
const RespawnManager = require("../players/respawn");
const PlayerManager = require("../players/playerManager");
const InfectionSystem = require("../players/infection");
const ZombieManager = require("../zombies/zombieManager");
const EventManager = require("../events/eventManager");
const { announceBoss } = require("../events/bossEvents");
const statsSys = require("../systems/stats");
const AfkSystem = require("../systems/afk");
const AntiSpam = require("../systems/antiSpam");
const AntiTroll = require("../systems/antiTroll");
const AntiExploit = require("../systems/antiExploit");
const AvatarManager = require("../players/avatarManager");
const TimerManager = require("../utils/timers");
const discord = require("../discord/webhook");
const { isAuthorizedAdmin } = require("../auth/admin");

class GameManager {
  constructor(room, Utils) {
    this.room = room;
    this.Utils = Utils;
    this.timers = new TimerManager();
    this.waveManager = new WaveManager();
    this.runManager = new RunManager();
    this.zombieManager = new ZombieManager(room, Utils);
    this.playerManager = new PlayerManager(room, this.zombieManager);
    this.respawn = new RespawnManager(room);
    this.avatarManager = new AvatarManager(room);
    this.infection = new InfectionSystem(
      room, statsSys, this.playerManager, this.zombieManager, this.avatarManager
    );
    this.eventManager = new EventManager(room, this);
    this.zombieManager.setDeps({
      infectionSys: this.infection,
      statsSys,
      playerManager: this.playerManager
    });
    this.afk = new AfkSystem(room, this);
    this.antiSpam = new AntiSpam(room);
    this.antiTroll = new AntiTroll(room);
    this.antiExploit = new AntiExploit(room, this.antiTroll);
    this.state = "WAITING";
    this.gameStarted = false;
    this.lastZombieUpdate = 0;
    this.countdownRemaining = 0;
    this.lastStandAnnounced = false;
    this.reinforceFired = new Set();
    this.waveStartAt = 0;
  }

  isFakeZombie(id) { return this.zombieManager.isZombie(id); }
  isAdmin(player) { return isAuthorizedAdmin(player); }

  startSystems() {
    this.afk.start();
    this.timers.setInterval(() => this._tick(), 200);
    this.timers.setInterval(() => this.antiTroll.decay(), 30000);
  }

  stopSystems() {
    this.afk.stop();
    this.timers.clearAll();
    this.zombieManager.clearAll();
  }

  tryStartRun() {
    if (this.state !== "WAITING") return;
    const humans = this.playerManager.getRealPlayers();
    if (humans.length < 1) return;
    if (!this.gameStarted) {
      try { this.room.startGame?.(0); this.gameStarted = true; } catch (_) {}
    }
    this.state = "RUNNING";
    this.runManager.start(humans.map((p) => p.name));
    discord.runStart(this.runManager.runId, humans.length);
    this.playerManager.resetInfected();
    this.respawn.clear();
    this.infection.clearAllOwned();
    this.avatarManager.clearAllTemporary();
    this.lastStandAnnounced = false;
    for (const p of humans) {
      try { this.room.setPlayerTeam?.(p.id, config.teams.HUMAN); } catch (_) {}
    }
    this._beginIntermissionThenWave(true);
  }

  _beginIntermissionThenWave(isFirst = false) {
    this.state = "INTERMISSION";
    this.zombieManager.clearAll();
    this.eventManager.endCurrent();
    const sec = Math.max(1, Math.round(config.wave.intermissionMs / 1000));
    this.countdownRemaining = sec;
    this._applyCountdownAvatars(sec);
    if (!isFirst) {
      this.room.sendAnnouncement?.(
        config.messages.intermission(config.wave.intermissionMs),
        null, 0xaaaaaa, "normal", 1
      );
    }
    const tickCountdown = () => {
      if (this.state !== "INTERMISSION") return;
      this.countdownRemaining -= 1;
      if (this.countdownRemaining > 0) {
        this._applyCountdownAvatars(this.countdownRemaining);
        this.timers.setTimeout(tickCountdown, 1000);
      } else {
        this._clearCountdownAvatars();
        this._startWave();
      }
    };
    this.timers.setTimeout(tickCountdown, 1000);
  }

  _countdownAvatar(n) {
    // HaxBall avatar ~2 chars: show remaining seconds as text (97, 96, ... 1)
    if (n > 99) return "99";
    if (n < 1) return "1";
    return String(n);
  }

  _applyCountdownAvatars(n) {
    if (!config.countdown?.enabled) return;
    const av = this._countdownAvatar(n);
    for (const p of this.playerManager.getRealPlayers()) {
      const team = p.team?.id ?? p.team;
      if (team === config.teams.SPECTATOR && !config.countdown.forSpectators) continue;
      this.avatarManager.setTemporary(p.id, "countdown", av, p.avatar);
    }
  }

  _clearCountdownAvatars() {
    for (const p of this.playerManager.getRealPlayers()) {
      this.avatarManager.restore(p.id, "countdown");
    }
  }

  _startWave() {
    const humanCount = Math.max(1, this.playerManager.getHumanCount() || this.playerManager.getRealPlayers().length);
    const info = this.waveManager.startNext(humanCount);
    this.runManager.setWave(info.wave);
    this.zombieManager.setWave(info.wave);
    this.reinforceFired.clear();
    this.waveStartAt = Date.now();
    this.lastStandAnnounced = false;
    const reals = this.playerManager.getRealPlayers();
    this.playerManager.resetInfected();
    this.infection.clearAllOwned();
    this.respawn.spawnHumans(reals);
    this.room.sendAnnouncement?.(config.messages.waveStart(info.wave, info.zombies), null, 0x00ff88, "bold", 2);
    if (info.boss) announceBoss(this.room);
    this.zombieManager.spawn(info.zombies, info.boss);
    discord.waveStart(info.wave, info.zombies, info.boss);
    this.eventManager.maybeStart(info.wave);
    this.state = "WAVE_ACTIVE";
  }

  _checkWaveEnd() {
    if (this.state !== "WAVE_ACTIVE") return;
    const zombiesLeft = this.zombieManager.getAliveCount();
    const humansAlive = this.playerManager.getHumanCount();
    if (humansAlive === 1 && !this.lastStandAnnounced) {
      const h = this.playerManager.getAliveHumans()[0];
      if (h) {
        this.lastStandAnnounced = true;
        this.room.sendAnnouncement?.(config.messages.lastSurvivor(h.name), null, 0xffaa00, "bold", 2);
        discord.lastSurvivor(h.name);
      }
    }
    if (humansAlive === 0) { this._runLost(); return; }
    if (zombiesLeft === 0) this._waveCleared(humansAlive);
  }

  _waveCleared(survivors) {
    this.waveManager.markCleared();
    this.state = "INTERMISSION";
    this.eventManager.endCurrent();
    for (const h of this.playerManager.getAliveHumans()) {
      if (h.auth) statsSys.waveSurvived(h.auth, this.waveManager.wave);
    }
    this.room.sendAnnouncement?.(config.messages.waveClear(this.waveManager.wave, survivors), null, 0x00ff00, "bold", 2);
    discord.waveClear(this.waveManager.wave, survivors);
    log.wave(`Wave ${this.waveManager.wave} cleared — ${survivors} survivors`);
    this._beginIntermissionThenWave(false);
  }

  _runLost() {
    const lostWave = this.waveManager.wave;
    this.state = "RUN_LOST";
    this.eventManager.endCurrent();
    this.zombieManager.clearAll();
    this.infection.clearAllOwned();
    this._clearCountdownAvatars();
    const summary = this.runManager.end(false, []);
    this.room.sendAnnouncement?.(config.messages.runLost(lostWave), null, 0xff0000, "bold", 2);
    if (summary) this.room.sendAnnouncement?.(summary, null, 0xffaa00, "normal", 1);
    discord.runLost(lostWave, this.runManager.runId);
    log.run(`RUN LOST at wave ${lostWave}`);
    this.timers.setTimeout(() => this._fullReset(), 5000);
  }

  _fullReset() {
    this.waveManager.reset();
    this.playerManager.resetInfected();
    this.respawn.clear();
    this.zombieManager.clearAll();
    this.infection.clearAllOwned();
    this.avatarManager.clearAllTemporary();
    this.state = "WAITING";
    this.lastStandAnnounced = false;
    for (const p of this.playerManager.getRealPlayers()) {
      try { this.room.setPlayerTeam?.(p.id, config.teams.HUMAN); } catch (_) {}
    }
    log.room("Full reset");
    this.timers.setTimeout(() => this.tryStartRun(), 2000);
  }

  _checkReinforcements() {
    if (!config.reinforcement?.enabled || this.state !== "WAVE_ACTIVE") return;
    const elapsed = (Date.now() - this.waveStartAt) / 1000;
    for (const entry of config.reinforcement.schedule) {
      if (this.reinforceFired.has(entry.afterSec)) continue;
      if (elapsed >= entry.afterSec) {
        this.reinforceFired.add(entry.afterSec);
        const spawned = this.zombieManager.spawnTyped(entry.count, entry.types);
        if (spawned.length) {
          this.room.sendAnnouncement?.(`🧟 Reinforcement: +${spawned.length}`, null, 0xff6600, "bold", 1);
          log.zombie(`Reinforcement +${spawned.length}`);
        }
      }
    }
  }

  _tick() {
    if (this.state === "WAITING") {
      if (this.playerManager.getRealPlayers().length >= 1) this.tryStartRun();
      return;
    }
    if (this.state === "WAVE_ACTIVE") {
      const now = Date.now();
      if (now - this.lastZombieUpdate >= config.movement.updateIntervalMs) {
        this.zombieManager.update();
        this.lastZombieUpdate = now;
      }
      this.eventManager.update(200);
      this._checkReinforcements();
      this._checkWaveEnd();
    }
  }

  onPlayerJoin(player) {
    this.playerManager.onJoin(player);
    statsSys.onJoin(player);
    this.afk.onActivity(player.id, "join");
    this.avatarManager.onJoin(player);
    if (this.state === "WAVE_ACTIVE" || this.state === "INTERMISSION") {
      this.respawn.queueForSpawn(player.id);
      try { this.room.setPlayerTeam?.(player.id, config.teams.SPECTATOR); } catch (_) {}
      this.room.sendAnnouncement?.(config.messages.playerJoinMid(this.waveManager.wave), player.id, 0x00aaff, "bold", 1);
      if (this.state === "INTERMISSION" && config.countdown?.enabled && this.countdownRemaining > 0) {
        const av = this._countdownAvatar(this.countdownRemaining);
        this.avatarManager.setTemporary(player.id, "countdown", av, player.avatar);
      }
    } else {
      try { this.room.setPlayerTeam?.(player.id, config.teams.HUMAN); } catch (_) {}
    }
  }

  onPlayerLeave(player) {
    this.playerManager.onLeave(player);
    statsSys.onLeave(player);
    this.afk.onLeave(player.id);
    this.antiSpam.onLeave(player.id);
    this.antiTroll.onLeave(player.id);
    this.antiExploit.onLeave(player.id);
    this.infection.onLeave(player.id);
    this.avatarManager.onLeave(player.id);
    if (this.state === "WAVE_ACTIVE") this.timers.setTimeout(() => this._checkWaveEnd(), 100);
  }

  onPlayerChat(player, message) {
    this.afk.onChat(player.id);
    if (!this.antiSpam.onChat(player, message)) return false;
    return true;
  }

  onPlayerInput(playerId, input) {
    if (this.isFakeZombie(playerId)) return;
    if (!this.antiExploit.checkInput(playerId, input)) return;
    this.afk.onActivity(playerId, "input");
  }

  onGameTick() {
    if (this.state !== "WAVE_ACTIVE") return;
    for (const h of this.playerManager.getAliveHumans()) {
      const d = this.room.getPlayerDisc?.(h.id) || this.room.getPlayerDiscProperties?.(h.id);
      if (d) this.afk.onPosition(h.id, d.x ?? d.pos?.x, d.y ?? d.pos?.y);
    }
  }

  onPlayerBallKick(playerId) {
    if (this.isFakeZombie(playerId)) return;
    this.afk.onActivity(playerId, "kick");
  }

  adminReset() { this._runLost(); }
  adminForceStart() { if (this.state === "WAITING") this.tryStartRun(); }
  adminNextWave() {
    if (this.state === "WAVE_ACTIVE") {
      this.zombieManager.eliminateAll();
      this._waveCleared(this.playerManager.getHumanCount());
    }
  }
  adminSetWave(n) { this.waveManager.wave = Math.max(0, n - 1); }
  adminSpawnBoss() { this.zombieManager.spawn(1, true); }
}

module.exports = GameManager;
