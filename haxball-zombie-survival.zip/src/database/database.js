const fs = require("fs");
const path = require("path");
const config = require("../config");
const log = require("../utils/logger");

/**
 * Simple JSON file store for persistent player stats & global records.
 * No external DB dependency.
 */

class Database {
  constructor() {
    this.filePath = path.resolve(config.database.path);
    this.data = {
      players: {},          // auth -> stats
      records: {
        highestWave: { value: 0, player: null, runId: null },
        longestSurvival: { value: 0, player: null },
        mostZombieKills: { value: 0, player: null },
        bestRun: { value: 0, player: null, runId: null },
        mostBossKills: { value: 0, player: null }
      },
      nextRunId: 1
    };
    this._dirty = false;
    this._saveTimer = null;
  }

  load() {
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, "utf8");
        const parsed = JSON.parse(raw);
        this.data = { ...this.data, ...parsed };
        log.stats("Database loaded");
      } else {
        this.save(true);
        log.stats("Database created");
      }
    } catch (e) {
      log.error("DB load failed:", e.message);
    }
  }

  save(force = false) {
    if (!force && !this._dirty) return;
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
      this._dirty = false;
      log.debug("DB saved");
    } catch (e) {
      log.error("DB save failed:", e.message);
    }
  }

  startAutoSave() {
    this._saveTimer = setInterval(() => this.save(), config.database.saveIntervalMs);
  }

  stopAutoSave() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this.save(true);
  }

  // ─── Player stats ───────────────────────────────────────────────────────

  _defaultStats() {
    return {
      kills: 0,
      deaths: 0,
      infections: 0,
      zombieKills: 0,
      wavesSurvived: 0,
      highestWave: 0,
      totalPlayTime: 0,
      bestRun: 0,
      bossKills: 0,
      runs: 0,
      wins: 0,
      losses: 0,
      survivalTime: 0,
      damage: 0,
      score: 0,
      name: ""
    };
  }

  getPlayer(auth) {
    if (!auth) return this._defaultStats();
    if (!this.data.players[auth]) {
      this.data.players[auth] = this._defaultStats();
      this._dirty = true;
    }
    return this.data.players[auth];
  }

  updatePlayer(auth, patch) {
    if (!auth) return;
    const p = this.getPlayer(auth);
    Object.assign(p, patch);
    this._dirty = true;
  }

  addStat(auth, key, amount = 1) {
    if (!auth) return;
    const p = this.getPlayer(auth);
    p[key] = (p[key] || 0) + amount;
    this._dirty = true;
  }

  // ─── Records ────────────────────────────────────────────────────────────

  getRecords() {
    return this.data.records;
  }

  tryRecord(key, value, playerName, extra = {}) {
    const rec = this.data.records[key];
    if (!rec) return false;
    if (value > rec.value) {
      this.data.records[key] = { value, player: playerName, ...extra };
      this._dirty = true;
      return true;
    }
    return false;
  }

  nextRunId() {
    const id = this.data.nextRunId++;
    this._dirty = true;
    return id;
  }

  // Top N by score
  getTop(n = 10) {
    return Object.entries(this.data.players)
      .map(([auth, s]) => ({ auth, ...s }))
      .sort((a, b) => (b.score || 0) - (a.score || 0))
      .slice(0, n);
  }
}

module.exports = new Database();
