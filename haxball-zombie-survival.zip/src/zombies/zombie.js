const { getType } = require("./zombieTypes");

let nextFakeId = 1000;

class Zombie {
  constructor(typeKey, spawnPos) {
    this.id = nextFakeId++;
    this.typeKey = typeKey;
    this.type = getType(typeKey);
    this.spawnPos = spawnPos || { x: 0, y: 0 };
    this.targetId = null;
    this.lastAttack = 0;
    this.lastInput = 0;
    this.stuckSince = 0;
    this.lastPos = { x: 0, y: 0 };
    this.alive = true;
    this.isBoss = typeKey === "BOSS";
    this.ownerPlayerId = null;
    this.name = this.isBoss
      ? this.type.name
      : `${this.type.name} #${this.id - 999}`;
  }

  static resetIdCounter(start = 1000) {
    nextFakeId = start;
  }
}

module.exports = Zombie;
