const config = require("../config");
const TYPES = config.zombieTypes;

function getType(key) {
  return TYPES[key] ? { key, ...TYPES[key] } : { key: "NORMAL", ...TYPES.NORMAL };
}

function pickFromWeights(weightMap) {
  const entries = Object.entries(weightMap).filter(([, w]) => w > 0);
  const total = entries.reduce((s, [, w]) => s + w, 0);
  if (total <= 0) return "NORMAL";
  let r = Math.random() * total;
  for (const [key, w] of entries) {
    r -= w;
    if (r <= 0) return key;
  }
  return entries[0][0];
}

function getBandForWave(wave) {
  const bands = config.difficultyBands || [];
  for (const b of bands) {
    if (wave <= b.maxWave) return b.types;
  }
  return { NORMAL: 100 };
}

function pickRandomType(wave = 1, excludeBoss = true) {
  const weights = getBandForWave(wave);
  const key = pickFromWeights(weights);
  if (excludeBoss && key === "BOSS") return getType("NORMAL");
  return getType(key);
}

function pickFromTypeList(types) {
  if (!types || !types.length) return getType("NORMAL");
  return getType(types[Math.floor(Math.random() * types.length)]);
}

module.exports = { TYPES, pickRandomType, getType, pickFromTypeList, getBandForWave };
