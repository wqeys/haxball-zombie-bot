const config = require("../config");

/**
 * Deterministic input generator for zombies.
 * Uses Utils.keyState when available.
 */
function computeInput(zombie, selfPos, targetPos, Utils) {
  if (!selfPos || !targetPos) return 0;

  const dx = targetPos.x - selfPos.x;
  const dy = targetPos.y - selfPos.y;
  const dist = Math.hypot(dx, dy);

  let dirX = 0;
  let dirY = 0;

  const threshold = 4;
  if (Math.abs(dx) > threshold) dirX = dx > 0 ? 1 : -1;
  if (Math.abs(dy) > threshold) dirY = dy > 0 ? 1 : -1;

  // Slight jitter when stuck
  if (zombie.stuckSince && Date.now() - zombie.stuckSince > 1500) {
    if (Math.random() < 0.3) dirX = -dirX || (Math.random() < 0.5 ? 1 : -1);
    if (Math.random() < 0.3) dirY = -dirY || (Math.random() < 0.5 ? 1 : -1);
  }

  const inRange = dist <= zombie.type.attackRange;
  const kick = inRange && (Date.now() - zombie.lastAttack > zombie.type.attackCooldownMs * 0.6);

  if (Utils && typeof Utils.keyState === "function") {
    return Utils.keyState(dirX, dirY, kick);
  }

  // Fallback bitmask: bit0=up,1=down,2=left,3=right,4=kick
  let input = 0;
  if (dirY === -1) input |= 1;
  if (dirY === 1) input |= 2;
  if (dirX === -1) input |= 4;
  if (dirX === 1) input |= 8;
  if (kick) input |= 16;
  return input;
}

function updateStuck(zombie, pos) {
  if (!pos) return;
  const dist = Math.hypot(pos.x - zombie.lastPos.x, pos.y - zombie.lastPos.y);
  if (dist < 3) {
    if (!zombie.stuckSince) zombie.stuckSince = Date.now();
  } else {
    zombie.stuckSince = 0;
    zombie.lastPos = { x: pos.x, y: pos.y };
  }
}

module.exports = { computeInput, updateStuck };
