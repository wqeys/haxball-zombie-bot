const config = require("../config");
const log = require("../utils/logger");

/**
 * Distance-based attack / infection logic (no AI).
 */
function tryAttack(zombie, targetPlayer, room, infectionSys, statsSys) {
  if (!zombie.alive || !targetPlayer) return false;
  const now = Date.now();
  if (now - zombie.lastAttack < zombie.type.attackCooldownMs) return false;

  const disc = room.getPlayerDisc?.(targetPlayer.id) ||
               room.getPlayerDiscProperties?.(targetPlayer.id);
  const zDisc = room.getPlayerDisc?.(zombie.id) ||
                room.getPlayerDiscProperties?.(zombie.id);
  if (!disc || !zDisc) return false;

  const dist = Math.hypot(
    (disc.x ?? disc.pos?.x ?? 0) - (zDisc.x ?? zDisc.pos?.x ?? 0),
    (disc.y ?? disc.pos?.y ?? 0) - (zDisc.y ?? zDisc.pos?.y ?? 0)
  );

  if (dist > zombie.type.attackRange) return false;

  zombie.lastAttack = now;

  // Knockback toward target direction
  const dx = (disc.x ?? 0) - (zDisc.x ?? 0);
  const dy = (disc.y ?? 0) - (zDisc.y ?? 0);
  const len = Math.hypot(dx, dy) || 1;
  const power = zombie.type.kickPower * 8;
  try {
    room.setPlayerDiscProperties?.(targetPlayer.id, {
      xspeed: (dx / len) * power,
      yspeed: (dy / len) * power
    });
  } catch (_) {}

  // Infection
  if (config.infection.enabled && config.infection.infectOnTouch) {
    infectionSys.infect(targetPlayer, zombie);
  }

  return true;
}

module.exports = { tryAttack };
