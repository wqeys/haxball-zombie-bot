const config = require("../config");
const Zombie = require("./zombie");
const { pickRandomType, getType, pickFromTypeList } = require("./zombieTypes");
const { computeInput, updateStuck } = require("./zombieMovement");
const { tryAttack } = require("./zombieCombat");
const log = require("../utils/logger");
const discord = require("../discord/webhook");

class ZombieManager {
  constructor(room, Utils) {
    this.room = room;
    this.Utils = Utils;
    this.zombies = new Map();
    this.frame = 0;
    this.infectionSys = null;
    this.statsSys = null;
    this.playerManager = null;
    this.currentWave = 1;
    this.spawnedAt = new Map(); // avoid same spawn spam
  }

  setDeps({ infectionSys, statsSys, playerManager }) {
    this.infectionSys = infectionSys;
    this.statsSys = statsSys;
    this.playerManager = playerManager;
  }

  setWave(w) {
    this.currentWave = w || 1;
  }

  isZombie(id) {
    return this.zombies.has(id);
  }

  getAlive() {
    return [...this.zombies.values()].filter((z) => z.alive);
  }

  getAliveCount() {
    return this.getAlive().length;
  }

  clearAll() {
    for (const z of this.zombies.values()) {
      this._removeFake(z);
    }
    this.zombies.clear();
    this.spawnedAt.clear();
    Zombie.resetIdCounter(1000);
  }

  _removeFake(z) {
    try {
      this.room.fakePlayerLeave?.(z.id);
    } catch (_) {}
    try {
      this.room.kickPlayer?.(z.id, null, false);
    } catch (_) {}
  }

  spawn(count, isBossWave = false) {
    const spawned = [];
    if (isBossWave) {
      const z = this._createOne("BOSS");
      if (z) {
        spawned.push(z);
        discord.bossSpawn();
      }
      count = Math.max(0, count - 1);
    }
    for (let i = 0; i < count; i++) {
      const type = pickRandomType(this.currentWave, true);
      const z = this._createOne(type.key);
      if (z) spawned.push(z);
    }
    log.zombie(`Spawned ${spawned.length} (wave=${this.currentWave} boss=${isBossWave})`);
    return spawned;
  }

  /** Reinforcement with preferred types */
  spawnTyped(count, typeKeys) {
    const spawned = [];
    for (let i = 0; i < count; i++) {
      const type = pickFromTypeList(typeKeys);
      const z = this._createOne(type.key);
      if (z) spawned.push(z);
    }
    return spawned;
  }

  /** Owned zombie for infected human (spectator) */
  spawnOwned(ownerPlayer, typeKey = "NORMAL") {
    const z = this._createOne(typeKey || "NORMAL", ownerPlayer);
    return z;
  }

  _createOne(typeKey, ownerPlayer = null) {
    const type = getType(typeKey);
    const pos = this._pickSpawn(typeKey === "BOSS");
    const z = new Zombie(typeKey, pos);
    if (ownerPlayer) {
      z.ownerPlayerId = ownerPlayer.id;
      z.name = `${type.name} (${ownerPlayer.name})`;
    }

    try {
      this.room.fakePlayerJoin?.(
        z.id,
        z.name,
        "xx",
        type.avatar,
        `fake-${z.id}`,
        `auth-fake-${z.id}`
      );
    } catch (e) {
      log.error("fakePlayerJoin failed:", e.message);
      return null;
    }

    setTimeout(() => {
      try {
        this.room.setPlayerTeam?.(z.id, config.teams.ZOMBIE);
        this.room.setPlayerDiscProperties?.(z.id, {
          x: pos.x,
          y: pos.y,
          radius: type.radius,
          invMass: type.invMass,
          bCoef: type.bCoef,
          xspeed: 0,
          yspeed: 0
        });
      } catch (e) {
        log.debug("zombie post-spawn:", e.message);
      }
    }, 50);

    this.zombies.set(z.id, z);
    if (z.isBoss) log.boss(`Boss spawned id=${z.id}`);
    return z;
  }

  _pickSpawn(isBoss) {
    const list =
      isBoss && config.spawn.boss.length
        ? config.spawn.boss
        : config.spawn.zombie;
    if (!list.length) {
      return {
        x: -150 + (Math.random() - 0.5) * 40,
        y: (Math.random() - 0.5) * 100
      };
    }
    // Prefer least recently used spawn
    let best = list[0];
    let bestT = Infinity;
    for (const p of list) {
      const key = `${p.x},${p.y}`;
      const t = this.spawnedAt.get(key) || 0;
      if (t < bestT) {
        bestT = t;
        best = p;
      }
    }
    this.spawnedAt.set(`${best.x},${best.y}`, Date.now());
    return { x: best.x, y: best.y };
  }

  update() {
    this.frame++;
    const alive = this.getAlive();
    if (!alive.length) return;

    const humans = this.playerManager
      ? this.playerManager.getAliveHumans()
      : [];

    const recalc = this.frame % config.movement.targetRecalcEvery === 0;

    for (const z of alive) {
      const zDisc =
        this.room.getPlayerDisc?.(z.id) ||
        this.room.getPlayerDiscProperties?.(z.id);
      if (!zDisc) continue;

      const zx = zDisc.x ?? zDisc.pos?.x ?? 0;
      const zy = zDisc.y ?? zDisc.pos?.y ?? 0;
      updateStuck(z, { x: zx, y: zy });

      if (recalc || z.targetId == null) {
        z.targetId = this._selectTarget(z, humans, zx, zy, alive);
      }

      const target = humans.find((h) => h.id === z.targetId);
      if (!target) {
        z.targetId = null;
        this.room.fakeSendPlayerInput?.(0, z.id);
        continue;
      }

      const tDisc =
        this.room.getPlayerDisc?.(target.id) ||
        this.room.getPlayerDiscProperties?.(target.id);
      if (!tDisc) continue;

      const tx = tDisc.x ?? tDisc.pos?.x ?? 0;
      const ty = tDisc.y ?? tDisc.pos?.y ?? 0;

      const input = computeInput(
        z,
        { x: zx, y: zy },
        { x: tx, y: ty },
        this.Utils
      );
      if (input !== z.lastInput) {
        this.room.fakeSendPlayerInput?.(input, z.id);
        z.lastInput = input;
      }

      if (this.infectionSys) {
        tryAttack(z, target, this.room, this.infectionSys, this.statsSys);
      }
    }
  }

  _selectTarget(z, humans, zx, zy, allZombies) {
    if (!humans.length) return null;
    const behavior = z.type.behavior || "nearest";

    if (behavior === "isolate" || behavior === "boss") {
      // Prefer humans farthest from other humans (lonely)
      let best = null;
      let bestScore = -Infinity;
      for (const h of humans) {
        const d =
          this.room.getPlayerDisc?.(h.id) ||
          this.room.getPlayerDiscProperties?.(h.id);
        if (!d) continue;
        const hx = d.x ?? 0;
        const hy = d.y ?? 0;
        const distZ = Math.hypot(hx - zx, hy - zy);
        if (distZ > config.movement.maxChaseDistance) continue;
        let nearestHuman = Infinity;
        for (const o of humans) {
          if (o.id === h.id) continue;
          const od =
            this.room.getPlayerDisc?.(o.id) ||
            this.room.getPlayerDiscProperties?.(o.id);
          if (!od) continue;
          nearestHuman = Math.min(
            nearestHuman,
            Math.hypot((od.x ?? 0) - hx, (od.y ?? 0) - hy)
          );
        }
        const score = nearestHuman - distZ * 0.3;
        if (score > bestScore) {
          bestScore = score;
          best = h.id;
        }
      }
      return best;
    }

    if (behavior === "swarm") {
      // Move toward centroid of nearby zombies, then toward human
      let cx = zx;
      let cy = zy;
      let n = 1;
      for (const oz of allZombies) {
        if (oz.id === z.id || !oz.alive) continue;
        const od =
          this.room.getPlayerDisc?.(oz.id) ||
          this.room.getPlayerDiscProperties?.(oz.id);
        if (!od) continue;
        const ox = od.x ?? 0;
        const oy = od.y ?? 0;
        if (Math.hypot(ox - zx, oy - zy) < 120) {
          cx += ox;
          cy += oy;
          n++;
        }
      }
      cx /= n;
      cy /= n;
      // Pick human closest to pack centroid
      let best = null;
      let bestDist = Infinity;
      for (const h of humans) {
        const d =
          this.room.getPlayerDisc?.(h.id) ||
          this.room.getPlayerDiscProperties?.(h.id);
        if (!d) continue;
        const dist = Math.hypot((d.x ?? 0) - cx, (d.y ?? 0) - cy);
        if (dist < bestDist) {
          bestDist = dist;
          best = h.id;
        }
      }
      return best;
    }

    // nearest
    let best = null;
    let bestDist = Infinity;
    for (const h of humans) {
      const d =
        this.room.getPlayerDisc?.(h.id) ||
        this.room.getPlayerDiscProperties?.(h.id);
      if (!d) continue;
      const dist = Math.hypot((d.x ?? 0) - zx, (d.y ?? 0) - zy);
      if (dist < bestDist && dist < config.movement.maxChaseDistance) {
        bestDist = dist;
        best = h.id;
      }
    }
    return best;
  }

  kill(zombieId, killerAuth) {
    const z = this.zombies.get(zombieId);
    if (!z || !z.alive) return;
    z.alive = false;
    if (killerAuth && this.statsSys) {
      if (z.isBoss) {
        this.statsSys.addBossKill(killerAuth);
        discord.bossKilled(null);
      } else {
        this.statsSys.addKill(killerAuth, true);
      }
    }
    this._removeFake(z);
    this.zombies.delete(zombieId);
    log.zombie(`${z.name} eliminated`);
  }

  eliminateAll() {
    for (const z of [...this.zombies.values()]) {
      this.kill(z.id, null);
    }
  }
}

module.exports = ZombieManager;
