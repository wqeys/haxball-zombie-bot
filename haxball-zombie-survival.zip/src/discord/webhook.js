/**
 * Discord webhook logger — event-driven only, never throws into game loop.
 * URL from process.env.DISCORD_WEBHOOK_URL only.
 */
const log = require("../utils/logger");

const MAX_PER_MINUTE = 20;
let sentThisMinute = 0;
let minuteStart = Date.now();

async function send(content, embeds) {
  const url = process.env.DISCORD_WEBHOOK_URL;
  if (!url) return;

  const now = Date.now();
  if (now - minuteStart > 60000) {
    minuteStart = now;
    sentThisMinute = 0;
  }
  if (sentThisMinute >= MAX_PER_MINUTE) return;
  sentThisMinute++;

  try {
    const body = { content: content || undefined, embeds: embeds || undefined };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      log.debug("Discord webhook HTTP", res.status);
    }
  } catch (e) {
    log.debug("Discord webhook failed:", e.message);
  }
}

function event(title, lines = []) {
  const text = ["🧟 **ZOMBIE SURVIVAL**", `**${title}**`, ...lines].join("\n");
  // fire-and-forget
  send(text).catch(() => {});
}

module.exports = {
  send,
  event,
  runStart: (runId, players) =>
    event("RUN START", [`RUN #${runId}`, `Players: ${players}`]),
  waveStart: (wave, zombies, boss) =>
    event(boss ? "BOSS WAVE" : "WAVE START", [
      `Wave ${wave}`,
      `Zombies: ${zombies}${boss ? " + BOSS" : ""}`
    ]),
  waveClear: (wave, survivors) =>
    event("WAVE CLEAR", [`Wave ${wave}`, `Survivors: ${survivors}`]),
  infected: (name, survivors) =>
    event("PLAYER INFECTED", [`☠ ${name}`, `Survivors: ${survivors}`]),
  lastSurvivor: (name) => event("LAST SURVIVOR", [`⚠ ${name}`]),
  bossSpawn: () => event("BOSS SPAWN", ["THE ZOMBIE BOSS HAS SPAWNED"]),
  bossKilled: (by) => event("BOSS KILLED", [by ? `By ${by}` : "Eliminated"]),
  runLost: (wave, runId) =>
    event("RUN LOST", [`RUN #${runId}`, `Wave ${wave}`]),
  record: (type, player, value) =>
    event("🏆 NEW RECORD", [type, `${player}: ${value}`]),
  kick: (name, reason) => event("PLAYER KICKED", [`${name}`, reason || ""]),
  ban: (name, reason) => event("PLAYER BANNED", [`${name}`, reason || ""]),
  antiTroll: (name, score) =>
    event("ANTI-TROLL", [`${name} score=${score}`]),
  antiSpam: (name) => event("ANTI-SPAM", [name])
};
