const config = require("../config");
const log = require("../utils/logger");
const discord = require("../discord/webhook");

/**
 * HUMAN → SPECTATOR + spawn owned fake zombie (player stays in room).
 */
class InfectionSystem {
  constructor(room, statsSys, playerManager, zombieManager, avatarManager) {
    this.room = room;
    this.statsSys = statsSys;
    this.pm = playerManager;
    this.zm = zombieManager;
    this.avatarManager = avatarManager;
    this.lastInfect = new Map();
    /** playerId → fake zombie id */
    this.ownedZombies = new Map();
  }

  infect(victim, byZombie) {
    if (!config.infection.enabled) return false;
    if (!victim || victim.id == null) return false;
    if (this.pm?.isFakeZombie?.(victim.id)) return false;

    const team = victim.team?.id ?? victim.team;
    if (team === config.teams.SPECTATOR && this.ownedZombies.has(victim.id)) {
      return false;
    }

    const now = Date.now();
    const last = this.lastInfect.get(victim.id) || 0;
    if (now - last < config.infection.infectCooldownMs) return false;
    this.lastInfect.set(victim.id, now);

    if (config.infection.moveToSpectator) {
      try {
        this.room.setPlayerTeam?.(victim.id, config.teams.SPECTATOR);
      } catch (_) {}
    } else {
      try {
        this.room.setPlayerTeam?.(victim.id, config.teams.ZOMBIE);
      } catch (_) {}
    }

    if (this.avatarManager) {
      this.avatarManager.setTemporary(
        victim.id,
        "infection",
        config.infection.zombieAvatar,
        victim.avatar
      );
    }

    if (this.zm && config.infection.moveToSpectator) {
      const spawned = this.zm.spawnOwned(victim, "NORMAL");
      if (spawned) this.ownedZombies.set(victim.id, spawned.id);
    }

    if (this.statsSys) this.statsSys.addDeath(victim.auth);
    if (this.pm) this.pm.markInfected(victim.id);

    this.room.sendAnnouncement?.(
      config.messages.infected(victim.name),
      null,
      0xff0000,
      "bold",
      2
    );

    const survivors = this.pm ? this.pm.getHumanCount() : 0;
    discord.infected(victim.name, survivors);
    log.infection(
      `${victim.name} infected` + (byZombie ? ` by ${byZombie.name}` : "")
    );
    return true;
  }

  clearOwned(playerId) {
    const zid = this.ownedZombies.get(playerId);
    if (zid != null && this.zm) this.zm.kill(zid, null);
    this.ownedZombies.delete(playerId);
    if (this.avatarManager) this.avatarManager.restore(playerId, "infection");
  }

  clearAllOwned() {
    for (const pid of [...this.ownedZombies.keys()]) this.clearOwned(pid);
  }

  onLeave(id) {
    this.clearOwned(id);
    this.lastInfect.delete(id);
  }
}

module.exports = InfectionSystem;
