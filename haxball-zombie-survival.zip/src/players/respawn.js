const config = require("../config");
const log = require("../utils/logger");

class RespawnManager {
  constructor(room) {
    this.room = room;
    this.pending = new Set(); // player ids waiting for next wave spawn
  }

  queueForSpawn(playerId) {
    this.pending.add(playerId);
  }

  isWaiting(playerId) {
    return this.pending.has(playerId);
  }

  /**
   * Spawn all waiting humans + reset living humans to human team / spawn.
   */
  spawnHumans(playerList) {
    const humans = [];
    for (const p of playerList) {
      if (p.id === 0) continue;
      // Skip if we know it's a fake zombie (checked outside)
      const team = p.team?.id ?? p.team;
      // Anyone not intentionally spectator
      if (this.pending.has(p.id) || team !== config.teams.SPECTATOR) {
        try {
          this.room.setPlayerTeam?.(p.id, config.teams.HUMAN);
          // Reset avatar/name if previously infected
          this.room.setPlayerAvatar?.(p.id, "");
        } catch (_) {}
        this.pending.delete(p.id);
        humans.push(p);

        // Optional position
        if (config.spawn.human.length) {
          const sp = config.spawn.human[Math.floor(Math.random() * config.spawn.human.length)];
          try {
            this.room.setPlayerDiscProperties?.(p.id, {
              x: sp.x, y: sp.y, xspeed: 0, yspeed: 0
            });
          } catch (_) {}
        }
      }
    }
    log.player(`Spawned/reset ${humans.length} humans`);
    return humans;
  }

  clear() {
    this.pending.clear();
  }
}

module.exports = RespawnManager;
