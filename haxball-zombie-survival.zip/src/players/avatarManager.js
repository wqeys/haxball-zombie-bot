/**
 * Central temporary avatar system — countdown / infection / events
 * don't stomp each other. Highest priority active reason wins.
 *
 * Priority (high → low): infection, countdown, event, rank, default
 */
const log = require("../utils/logger");

const PRIORITY = {
  infection: 100,
  countdown: 50,
  event: 30,
  rank: 10
};

class AvatarManager {
  constructor(room) {
    this.room = room;
    /** @type {Map<number, { original: string, layers: Map<string, string> }>} */
    this.state = new Map();
  }

  _ensure(playerId, currentAvatar) {
    if (!this.state.has(playerId)) {
      this.state.set(playerId, {
        original: currentAvatar || "",
        layers: new Map()
      });
    }
    return this.state.get(playerId);
  }

  setTemporary(playerId, reason, avatar, currentAvatar) {
    const s = this._ensure(playerId, currentAvatar);
    s.layers.set(reason, avatar);
    this._apply(playerId);
  }

  restore(playerId, reason) {
    const s = this.state.get(playerId);
    if (!s) return;
    s.layers.delete(reason);
    this._apply(playerId);
  }

  _apply(playerId) {
    const s = this.state.get(playerId);
    if (!s) return;

    let bestReason = null;
    let bestPri = -1;
    for (const reason of s.layers.keys()) {
      const p = PRIORITY[reason] ?? 0;
      if (p > bestPri) {
        bestPri = p;
        bestReason = reason;
      }
    }

    const avatar =
      bestReason != null ? s.layers.get(bestReason) : s.original;

    try {
      this.room.setPlayerAvatar?.(playerId, avatar);
    } catch (e) {
      log.debug("setPlayerAvatar failed", e.message);
    }
  }

  /**
   * Capture original avatar on join if not yet stored.
   */
  onJoin(player) {
    if (!player || player.id == null) return;
    const av = player.avatar != null ? String(player.avatar) : "";
    if (!this.state.has(player.id)) {
      this.state.set(player.id, { original: av, layers: new Map() });
    }
  }

  onLeave(playerId) {
    this.state.delete(playerId);
  }

  getOriginal(playerId) {
    return this.state.get(playerId)?.original ?? "";
  }

  /** Force-clear all temporary layers (e.g. run reset) */
  clearAllTemporary() {
    for (const [id, s] of this.state) {
      s.layers.clear();
      this._apply(id);
    }
  }
}

module.exports = AvatarManager;
