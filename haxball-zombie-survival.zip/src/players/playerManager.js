const config = require("../config");
const log = require("../utils/logger");

class PlayerManager {
  constructor(room, zombieManager) {
    this.room = room;
    this.zm = zombieManager;
    this.infectedIds = new Set();
    this.joinTimes = new Map();
  }

  onJoin(player) {
    this.joinTimes.set(player.id, Date.now());
    log.player(`${player.name} joined (id=${player.id})`);
  }

  onLeave(player) {
    this.infectedIds.delete(player.id);
    this.joinTimes.delete(player.id);
    log.player(`${player.name} left`);
  }

  markInfected(id) {
    this.infectedIds.add(id);
  }

  isInfected(id) {
    return this.infectedIds.has(id);
  }

  isFakeZombie(id) {
    return this.zm && this.zm.isZombie(id);
  }

  /**
   * Real human players currently on BLUE and not infected.
   */
  getAliveHumans() {
    const list = this.room.players || [];
    return list.filter(p => {
      if (p.id === 0) return false;
      if (this.isFakeZombie(p.id)) return false;
      if (this.infectedIds.has(p.id)) return false;
      const team = p.team?.id ?? p.team;
      return team === config.teams.HUMAN;
    });
  }

  getHumanCount() {
    return this.getAliveHumans().length;
  }

  /**
   * All real players (not fake zombies).
   */
  getRealPlayers() {
    const list = this.room.players || [];
    return list.filter(p => p.id !== 0 && !this.isFakeZombie(p.id));
  }

  resetInfected() {
    this.infectedIds.clear();
  }
}

module.exports = PlayerManager;
