// Boss-specific messaging helpers (boss spawn is handled by ZombieManager)
const log = require("../utils/logger");

function announceBoss(room) {
  room.sendAnnouncement?.("☠ BOSS WAVE", null, 0x8b0000, "bold", 2);
  room.sendAnnouncement?.("THE ZOMBIE BOSS HAS SPAWNED", null, 0xff0000, "bold", 2);
  log.boss("Boss wave announced");
}

module.exports = { announceBoss };
