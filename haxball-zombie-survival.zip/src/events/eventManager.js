const config = require("../config");
const log = require("../utils/logger");
const randomEvents = require("./randomEvents");

class EventManager {
  constructor(room, gameManager) {
    this.room = room;
    this.gm = gameManager;
    this.active = null;
  }

  maybeStart(waveNum) {
    if (!config.events.enabled) return;
    if (waveNum < config.events.minWave) return;
    if (this.active) return;
    if (Math.random() > config.events.chancePerWave) return;

    const list = config.events.list;
    const name = list[Math.floor(Math.random() * list.length)];
    const EventClass = randomEvents[name];
    if (!EventClass) return;

    this.active = new EventClass(this.room, this.gm);
    this.active.start();
    log.event(`Event started: ${name}`);
  }

  update(dt) {
    if (!this.active) return;
    if (this.active.update) this.active.update(dt);
    if (this.active.finished) {
      this.active.end();
      log.event(`Event ended: ${this.active.constructor.name}`);
      this.active = null;
    }
  }

  endCurrent() {
    if (this.active) {
      this.active.end();
      this.active = null;
    }
  }
}

module.exports = EventManager;
