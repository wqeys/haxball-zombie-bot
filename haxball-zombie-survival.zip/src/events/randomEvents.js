const config = require("../config");

class BaseEvent {
  constructor(room, gm) {
    this.room = room;
    this.gm = gm;
    this.finished = false;
    this.startTime = Date.now();
  }
  start() {}
  update() {}
  end() { this.finished = true; }
}

class ZombieRush extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: ZOMBIE RUSH", null, 0xff6600, "bold", 2);
    // Spawn extra 3 zombies
    if (this.gm.zombieManager) {
      this.gm.zombieManager.spawn(3, false);
    }
    this.duration = 20000;
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    this.room.sendAnnouncement?.("Zombie Rush ended.", null, 0xaaaaaa, "normal", 1);
    super.end();
  }
}

class DoubleZombies extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: DOUBLE ZOMBIES", null, 0xff6600, "bold", 2);
    const extra = Math.ceil((this.gm.waveManager?.zombieTarget || 2) / 2);
    this.gm.zombieManager?.spawn(extra, false);
    this.duration = 15000;
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    super.end();
  }
}

class FastZombies extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: FAST ZOMBIES", null, 0xff6600, "bold", 2);
    this.duration = 25000;
    // Temporarily boost speeds via disc props if possible
    for (const z of this.gm.zombieManager?.getAlive() || []) {
      try {
        this.room.setPlayerDiscProperties?.(z.id, { invMass: Math.min(1.2, z.type.invMass * 1.4) });
      } catch (_) {}
    }
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    super.end();
  }
}

class LowGravity extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: LOW GRAVITY", null, 0x00ccff, "bold", 2);
    this.duration = 20000;
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    super.end();
  }
}

class SuperKnockback extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: SUPER KNOCKBACK", null, 0xff6600, "bold", 2);
    this.duration = 20000;
    // Combat system reads type.kickPower; we could patch temporarily
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    super.end();
  }
}

class NoSafeZone extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: NO SAFE ZONE", null, 0xff0000, "bold", 2);
    this.duration = 30000;
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    super.end();
  }
}

class OneMinuteHorde extends BaseEvent {
  start() {
    this.room.sendAnnouncement?.("⚡ EVENT: ONE MINUTE HORDE", null, 0xff0000, "bold", 2);
    this.gm.zombieManager?.spawn(6, false);
    this.duration = 60000;
  }
  update() {
    if (Date.now() - this.startTime > this.duration) this.finished = true;
  }
  end() {
    this.room.sendAnnouncement?.("Horde event ended.", null, 0xaaaaaa, "normal", 1);
    super.end();
  }
}

module.exports = {
  ZombieRush,
  DoubleZombies,
  FastZombies,
  LowGravity,
  SuperKnockback,
  NoSafeZone,
  OneMinuteHorde
};
