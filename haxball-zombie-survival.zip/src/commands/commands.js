const statsSys = require("../systems/stats");
const { formatTop, formatRecords, formatStats, formatProfile } = require("../systems/leaderboard");
const { isAuthorizedAdmin } = require("../auth/admin");
const log = require("../utils/logger");

function handleCommand(room, player, message, gameManager) {
  if (!message.startsWith("!")) return false;
  const parts = message.slice(1).trim().split(/\s+/);
  const cmd = (parts[0] || "").toLowerCase();
  const arg = parts[1];
  const reply = (text) => room.sendAnnouncement?.(text, player.id, 0x00ffcc, "normal", 1);
  const adminOnly = () => {
    if (!isAuthorizedAdmin(player)) { reply("Unauthorized."); return false; }
    return true;
  };

  switch (cmd) {
    case "stats": {
      const s = statsSys.getProfile(player.auth); s.name = player.name; reply(formatStats(s)); return true;
    }
    case "profile": {
      const s = statsSys.getProfile(player.auth); s.name = player.name; reply(formatProfile(s)); return true;
    }
    case "rank": {
      const s = statsSys.getProfile(player.auth);
      reply(`Your rank: ${s.rank || "ROOKIE"} (score ${s.score || 0})`); return true;
    }
    case "top": reply(formatTop(10)); return true;
    case "records": reply(formatRecords()); return true;
    case "wave": {
      const wm = gameManager.waveManager;
      reply(`Wave: ${wm.wave} | State: ${gameManager.state} | Zombies: ${gameManager.zombieManager.getAliveCount()} | Humans: ${gameManager.playerManager.getHumanCount()}`);
      return true;
    }
    case "run": reply(gameManager.runManager.getSummaryLine() || "No active run."); return true;
    case "help":
      reply("Player: !stats !profile !rank !top !records !wave !run\nAdmin: !reset !forcestart !nextwave !setwave N !boss !zombies !debug");
      return true;
    case "reset":
      if (!adminOnly()) return true;
      log.room(`Admin ${player.name} !reset`);
      gameManager.adminReset(); reply("Run reset."); return true;
    case "forcestart":
      if (!adminOnly()) return true;
      gameManager.adminForceStart(); reply("Force start."); return true;
    case "nextwave":
      if (!adminOnly()) return true;
      gameManager.adminNextWave(); reply("Wave forced clear."); return true;
    case "setwave": {
      if (!adminOnly()) return true;
      const n = parseInt(arg, 10);
      if (!n || n < 1) { reply("Usage: !setwave 10"); return true; }
      gameManager.adminSetWave(n); reply(`Next wave will be ${n}.`); return true;
    }
    case "boss":
      if (!adminOnly()) return true;
      gameManager.adminSpawnBoss(); reply("Boss spawned."); return true;
    case "zombies":
      if (!adminOnly()) return true;
      reply(`Alive zombies: ${gameManager.zombieManager.getAliveCount()}`); return true;
    case "spawnzombie": {
      if (!adminOnly()) return true;
      const c = Math.min(5, parseInt(arg, 10) || 1);
      gameManager.zombieManager.spawn(c, false); reply(`Spawned ${c}.`); return true;
    }
    case "debug":
      if (!adminOnly()) return true;
      reply(`state=${gameManager.state} wave=${gameManager.waveManager.wave} humans=${gameManager.playerManager.getHumanCount()} zombies=${gameManager.zombieManager.getAliveCount()} run=#${gameManager.runManager.runId} countdown=${gameManager.countdownRemaining}`);
      return true;
    case "admin":
      if (!adminOnly()) return true;
      reply("You are authorized admin."); return true;
    default: return false;
  }
}

module.exports = { handleCommand };
