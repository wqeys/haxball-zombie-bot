/**
 * Centralized admin authorization by player.auth only (never by name).
 */
const config = require("../config");

function getAdminAuthList() {
  const fromEnv = process.env.ADMIN_AUTH || "";
  const envList = fromEnv
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const fromConfig = Array.isArray(config.adminAuths) ? config.adminAuths : [];
  return [...new Set([...envList, ...fromConfig])];
}

function isAuthorizedAdmin(player) {
  if (!player || !player.auth) return false;
  const list = getAdminAuthList();
  return list.includes(player.auth);
}

module.exports = { isAuthorizedAdmin, getAdminAuthList };
